<?php
$to = "contact@lennerttorfs.be";
$subject = "onderwerp";
$message = "Hello world!";
$headers = "From: lennerttorfs@hotmail.be"
mail($to, $subject, $message, $headers);
$whatever = $_POST["naam"]
$whatever = $_POST["onderwerp"]

?>